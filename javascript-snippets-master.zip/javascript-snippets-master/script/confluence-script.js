
// Always go to the top of the page when you are in the middle of the confluence page.
$('#top').click(function() {
	window.scrollTo(0,0);
	
	return false;
});
$(function() {
		$('#top').hide();
});

$(window).scroll(function() {
		$('#top').show();
});
