
var str = "hello";

function revStr1(str){
  var strLen = str.length;

  if(strLen && strLen !== null){
    var revStr = str.split("").reverse().join("");
  }
  console.log(revStr);
}

function revstr2(str){
	var strLen = str.length;

	if(strLen && strLen !== null){
		var strArr = str.split("");
		var strRev = "";
		
		for(var i = strLen-1; i >= 0; i--){
				strRev += strArr[i];
			}
	}
		console.log(strRev);
}

revstr2(str);