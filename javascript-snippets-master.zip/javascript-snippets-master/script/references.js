function sayHello(name){
    var text = 'Hello ' + name;
    var say = function(){
        console.log(text);
    };
    console.log("say: ",say);
    return say;
}
var say2 = sayHello("john");
console.log("say2: ",say2);
say2();