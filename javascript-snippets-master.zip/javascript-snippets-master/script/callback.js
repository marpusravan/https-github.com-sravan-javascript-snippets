function add(a,b,c){
	return a+b;
}

function math(cb){
	var result = cb(2,3);
	console.log(result);
}

math(add);
//-----------------------------------------------------------------------------
function cbTest(name, func) {
    func(name);
}


cbTest("doe", function(name){
    console.log("Hello ",name);
});

//-----------------------------------------------------------------------------

function getName(name){
    return name;
}

function cbTest(name,cb){
    console.log("hello ",cb(name));
}

cbTest("John",getName);