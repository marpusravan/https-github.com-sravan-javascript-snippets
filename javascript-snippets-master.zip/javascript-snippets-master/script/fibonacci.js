(function fibo1(n){
	console.log("fibo1: ");

	var arr = [0,1];
  
  for(var i=2;i<=n;i++){
    arr.push(arr[i-1]+arr[i-2]);
  }
    console.log(arr);
})(10),

(function fibo2(n){
	console.log("fibo2: ");
	var first=0;
	var second = 1;
	var sum = 0;
	var arr = [];

	arr.push(first);
	arr.push(second);

	for(var i=2;i<=n;i++){
		sum = first + second
		arr.push(sum);
		first = second;
		second = sum;

	}
	console.log(arr);
})(10),

(function fibo3(n){
	console.log("fibo3: ");
	var arr=[0,1];
	var sum = 0;
	var previous, current;

	for(var i=2;i<=n;i++){
		
		previous = arr[i-2];
		current = arr[i-1];

		sum = previous + current;
		arr.push(sum);
		
	}

	console.log(arr);
})(10),

(function fibo4(n){
	console.log("fibo4: ");
	var arr = [];

	arr[0] = 0;
	arr[1] = 1;
	for(var i=2; i<=n; i++)
	{
	    arr[i] = arr[i-2] + arr[i-1];
	}
	console.log(arr)
})(10),

(function fibo5(n){
	console.log("fibo5 - nth number");

	var a = 0, b = 1, f = 1;

	for(var i=2;i<=n;i++){
		f = a + b;
		a = b;
		b = f;
	}
	console.log(f);
})(10);

var fiboRecursion = function (n)   
{  

  if (n===1)   
  {  
    return [0, 1];  
  }   
  else   
  {  
    var series = fiboRecursion(n - 1);  
    series.push(series[series.length - 1] + series[series.length - 2]);  
    return series;  
  }  
};  
  
 console.log(fiboRecursion(10)); 

