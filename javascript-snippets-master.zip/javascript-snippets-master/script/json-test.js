var sample = {
    "first_name":"john",
    "last_name": "doe"
};

console.log("chk1: ",sample);

sample.first_name = "jane";

console.log("chk2: ",sample);