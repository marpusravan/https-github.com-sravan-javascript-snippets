var person = {
	set firstName(name){
    	this.myarr.push(name);
    },
  get firstName(){
  	if(this.myarr.length){ 
  	 	console.log(this.myarr.length);
  	 	return this.myarr;
  	 }
    },
    myarr : []
}

person.firstName = "doe"; // Invokes setter
console.log(person.myarr);
console.log(person.firstName); // Invokes getter



