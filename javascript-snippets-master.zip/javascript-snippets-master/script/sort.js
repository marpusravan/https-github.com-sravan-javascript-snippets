// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/sort

// The sort() method sorts the elements of an array in place and returns the array. The sort is not necessarily stable. 
// RETURNS : SORTED ARRAY

// SYNTAX
// arr.sort()
// arr.sort(compareFunction)
// pseudo code for compare
// function compare(a, b) {
//   if (a is less than b by some ordering criterion) {
//     return -1;
//   }
//   if (a is greater than b by the ordering criterion) {
//     return 1;
//   }
//   // a must be equal to b
//   return 0;
// }

var fruit = ['cherries', 'apples', 'bananas'];
fruit.sort(); // ['apples', 'bananas', 'cherries']

var scores = [1, 10, 21, 2]; 
scores.sort(); // [1, 10, 2, 21]


var numbers = [4, 2, 5, 1, 3];
numbers.sort(function(a, b) { 
  return a - b;
});
console.log("numbers: ",numbers); // [1, 2, 3, 4, 5]


function compareNumbers(a, b) {
  return a - b;
}

var stringArray = ['Blue', 'Humpback', 'Beluga'];
console.log('stringArray:', stringArray.join());
console.log('Sorted:', stringArray.sort());

var numberArray = [40, 1, 5, 200];
console.log('numberArray:', numberArray.join());
console.log('Sorted without a compare function:', numberArray.sort());
console.log('Sorted with compareNumbers:', numberArray.sort(compareNumbers));

// numberArray: 40,1,5,200
// Sorted without a compare function: 1,200,40,5
// Sorted with compareNumbers: 1,5,40,200



// NON-ENGLISH / ACCENTED ARRAYS
var items = ['réservé', 'premier', 'cliché', 'communiqué', 'café', 'adieu'];
items.sort(function (a, b) {
  return a.localeCompare(b); // use localCompare for accented arrays
});

// items is ['adieu', 'café', 'cliché', 'communiqué', 'premier', 'réservé']


// The compareFunction can be invoked multiple times per element within the array. Depending on the compareFunction's nature, this may yield a high overhead. The more work a compareFunction does and the more elements there are to sort, the wiser it may be to consider using a map for sorting. The idea is to walk the array once to extract the actual values used for sorting into a temporary array, sort the temporary array and then walk the temporary array to achieve the right order.

// the array to be sorted
var list = ['Delta', 'alpha', 'CHARLIE', 'bravo'];

// temporary array holds objects with position and sort-value
var mapped = list.map(function(el, i) {
  return { index: i, value: el.toLowerCase() };
})

// sorting the mapped array containing the reduced values
mapped.sort(function(a, b) {
  return +(a.value > b.value) || +(a.value === b.value) - 1;
});

// container for the resulting order
var result = mapped.map(function(el){
  return list[el.index];
});