function swap(a,b){
	var temp = a;
	a = b;
	b = temp;

	console.log(a,b);
}

function swap2(a,b){
	a = a + b; // sum of two numbers
	b = a - b; // extract b
	a = a - b; // extract a

	console.log(a,b);
}

swap(10,5);
swap2(10,5);