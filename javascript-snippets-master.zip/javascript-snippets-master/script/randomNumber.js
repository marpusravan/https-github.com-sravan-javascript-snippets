function getRandomBucketValue(min,max){
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

var random = getRandomBucketValue(0,3);
console.log(random);