// Merge as sorted array.

function mergeSortedArray(a1,a2){
	console.log("a1: ",a1," a2: ",a2);
	concatArr =	a1.concat(a2);
	return concatArr.sort(function(a,b){ // compare function to make a stable sort
		console.log("a: ",a," b: "," a-b: ",a-b);
		return a - b; // return 
	});
}

a1 = [2,5,6,9];
a2 = [1,2,3,29];
console.log(mergeSortedArray(a1, a2));

// OUTPUT
// a1:  [ 2, 5, 6, 9 ]  a2:  [ 1, 2, 3, 29 ]
// a:  2  b:   a-b:  -3
// a:  5  b:   a-b:  -1
// a:  6  b:   a-b:  -3
// a:  9  b:   a-b:  8
// a:  6  b:   a-b:  5
// a:  5  b:   a-b:  4
// a:  2  b:   a-b:  1
// a:  9  b:   a-b:  7
// a:  6  b:   a-b:  4
// a:  5  b:   a-b:  3
// a:  2  b:   a-b:  0
// a:  9  b:   a-b:  6
// a:  6  b:   a-b:  3
// a:  5  b:   a-b:  2
// a:  2  b:   a-b:  -1
// a:  9  b:   a-b:  -20
// [ 1, 2, 2, 3, 5, 6, 9, 29 ]
