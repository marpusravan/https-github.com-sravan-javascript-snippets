// FUNCTION EXPRESSIONS
var greeting = function(){
	console.log("Hello world !");
}
// greeting();


// NESTED FUNCTIONS
function mul(a){
	function mulb(b){
		function mulc(c){
			console.log("result: ",a*b*c);
		}
		return mulc;
	}
	return mulb;
}
// mul(2)(3)(4);

function add(a){
	return function(b){
		return function(c){
			console.log("add: ",a+b+c);
		};
	};
}
// add(2)(3)(4);


function A(x) {
	//A doesn't have access to B's y and C's Z
  function B(y) {
  	// B doesn't have access to C's Z
    function C(z) {
    	// C can access B's, A's variables
      console.log(x + y + z);
    }
    C(3);
  }
  B(2);
}
// A(1); // logs 6 (1 + 2 + 3)


// When two arguments or variables in the scopes of a closure have the same name, there is a name conflict. More inner scopes take precedence, so the inner-most scope takes the highest precedence, while the outer-most scope takes the lowest. This is the scope chain. The first on the chain is the inner-most scope, and the last is the outer-most scope.
function outside() {
  var x = 10;
  function inside(x) {
    return x;
  }
  return inside;
}
// result = outside()(20); // returns 20 instead of 10


// CLOSURES

var createPet = function(name){
	var sex;

	return {
		getName: function(){
			return name;
		},
		setName : function(newName){
			name = newName;
		},
		getSex : function(){
			return sex;
		},
		setSex : function(newSex){
			sex = newSex;
		}
	}
}


var pet = createPet('Vivie');
// console.log(pet.getName());  // Vivie

pet.setName('Oliver');
// console.log(pet.getName());   // Oliver

pet.setSex('male');
// console.log(pet.getSex());   // male



//ARGUMENTS VARIABLE
function myConcat(seperator){
	var result = '';
	// console.log(arguments.length)
	for(var i=1;i<arguments.length;i++){
		result += arguments[i];
		if(i != arguments.length-1){
			result += seperator;
		}
	}

	return result;
}

// returns "red, orange, blue, "
// console.log(myConcat(', ', 'red', 'orange', 'blue'));

// // returns "elephant; giraffe; lion; cheetah; "
// console.log(myConcat('; ', 'elephant', 'giraffe', 'lion', 'cheetah'));

// // returns "sage. basil. oregano. pepper. parsley. "
// console.log(myConcat('. ', 'sage', 'basil', 'oregano', 'pepper', 'parsley'));


// DEFAULT PARAMETERS
function multiply(a, b = 5){ //defaulting b to 5
	return a*b;
}
// console.log(multiply(5)); // 5


// REST PARAMETERS

function multiply(multiplier, ...myArguments){ // ... (three dots)
	return myArguments.map(x => multiplier*x);
}

var arr = multiply(2, 1, 2, 3);
console.log(arr); // [2, 4, 6]

