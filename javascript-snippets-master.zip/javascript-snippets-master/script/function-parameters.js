function check2Params(param1,param2){
	// console.log("param1: ",param1);
	console.log("param1: ",param1,"param2: ",param2);
	// console.log("param1: ",param1,"param2: ",param2,"param3: ",param3);
}

function check3Params(param1,param2,param3){
	// console.log("param1: ",param1);
	console.log("param1: ",param1,"param2: ",param2);
	// console.log("param1: ",param1,"param2: ",param2,"param3: ",param3);
}

check2Params("test1","test2","test3");
// check3Params("test1"); // test1 undefined undefined
// check3Params("test1","test2"); // test1 test2 test3