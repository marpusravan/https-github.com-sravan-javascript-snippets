// Pair of elements from an specified array whose sum equals a specific target number

function twoSum(nums, target_num) {
  var map = [];
  var indexnum = [];
  
  for (var x = 0; x < nums.length; x++)
  {
  if (map[nums[x]] != null) // check if map to current nums[x] 
    {
    index = map[nums[x]]; // value of mapElement ( which is index of remaining pair element)
    indexnum[0] = index+1; // value of mapElement + 1
    indexnum[1] = x+1; // index of mapElement
    break;
    }else {
      map[target_num - nums[x]] = x; // targetElement - currentNumber gives remaining pair element and at that map[remaining] = store current element's index. That is linking current element and remaining element.
    }
  }
  return indexnum;
  }

var indexes = twoSum([10,20,10,40,50,60,70],50);
console.log(indexes);


