function isAnagram(word1, word2){
	var str1 = word1.split("").sort().join();
	var str2 = word1.split("").sort().join();
	if(str1 === str2){
		return true;
	}else{
		return false;
	}
}

var result = isAnagram("cat","mat");
console.log(result);