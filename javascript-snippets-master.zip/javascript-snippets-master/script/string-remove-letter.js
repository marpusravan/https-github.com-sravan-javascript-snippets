// remove letter except if it is in first and last place of the string
// XAXBXCY => XABCY
//XAXBXCX => XABCX
//XAxxxXBxCX => XABCX

var str = "XAxxxXBxCX"; 
var letter = "X";

function removeLetter2(str, letter){
  var firstChar = str.charAt(0);
  var lastChar = str.charAt(str.length - 1);

    str2 = str.slice(1,str.length-1);

    while(str2.indexOf(letter) != -1){
      for(var i=1;i< str2.length-1;i++){
        if(str2.charAt(i).toLowerCase() == letter.toLowerCase()){
          str2 = str2.replace(str2.charAt(i),"");
        }
      }  
    }
    
  str2 = firstChar + str2 + lastChar;
    console.log(str2);
  
}

removeLetter2(str,letter);
