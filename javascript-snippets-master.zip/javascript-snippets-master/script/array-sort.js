var unsortedArr = [20,50, 20, 49,68];

function sortArray(arr){
	console.log(arr.sort());
}

sortArray(unsortedArr);