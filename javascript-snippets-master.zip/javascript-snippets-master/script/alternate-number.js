(function(n){
	for(var i=0;i<n;i=i+2){
  console.log(i);
  }

})(10);