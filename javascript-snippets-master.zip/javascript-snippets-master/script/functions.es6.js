"use strict"
let add = (a,b) => {
    return a+b;
};
// console.log(add(2,3));


// THIS
function person() {
	console.log(this); // {}
  this.age = 0;

  	var timer = setInterval(() => {
  		if(this.age > 3){
  			clearInterval(timer); //clear interval and comeout of it
	  	}else{
	  	  console.log(this.age++);
	  	}
  	}, 1000);
}

new person();