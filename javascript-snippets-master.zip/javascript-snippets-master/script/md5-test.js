

// require(['md5'],function(md5) {
	// $( document ).ready(function() {alert("hi")
	// 			var hash = md5("welcome");
	// console.log(hash);
	// });


// });

// function md5_encrypt(plainStr){
//     var encStr = null;
//     require(['domReady','md5'],function(domReady,md5){
//     	domReady(function(){
//         	encStr = md5(plainStr);
//     	});
//     });
//     return encStr;
// }
// 
function md5_encrypt(str){
	return md5(str);
}
var res = md5_encrypt("900586864");
console.log("res: ",res);