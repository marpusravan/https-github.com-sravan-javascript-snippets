//A prime number (or a prime) is a natural number greater than 1 that has no positive divisors other than 1 and itself. A natural number greater than 1 that is not a prime number is called a composite number.


function isPrime(number){
	var divisor = 2;

	while(number > divisor){
		if(number % divisor == 0){
			return false;
		}else{
			divisor++;
		}
	}

	return true;
}

console.log(isPrime(10));
console.log(isPrime(11));