$(document).ready(function(){
	document.cookie = "username=Jane Doe";
	
});
