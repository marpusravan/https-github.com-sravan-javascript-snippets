function Person(first, last, age, gender, interests){
	this.name = {
    first,
    last
  };
  this.age = age;
  this.gender = gender;
  this.interests = interests;
}

Person.prototype.greeting = function(){
	console.log("Hello, "+this.name.first);
}


var johnInfo = new Person("john","doe");
johnInfo.greeting();


function Teacher(first, last, age, gender, interests, subject) {
  Person.call(this, first, last, age, gender, interests); // calls the function defined on Person

  this.subject = subject; // adds additional property "subject" to teacher 
}


// Teacher.prototype = Object.create(Person.prototype); //create a new object based on the value of the object refered by Person.prototype.
//Teacher.prototype will now inherit all the methods available on Person.prototype.
//Teacher.prototype will now inherit all the methods available on Person.prototype.

Teacher.prototype.constructor = Teacher;

Teacher.prototype.greeting = function() {
  var prefix;

  if (this.gender === 'male' || this.gender === 'Male' || this.gender === 'm' || this.gender === 'M') {
    prefix = 'Mr.';
  } else if (this.gender === 'female' || this.gender === 'Female' || this.gender === 'f' || this.gender === 'F') {
    prefix = 'Mrs.';
  } else {
    prefix = 'Mx.';
  }

  console.log('Hello. My name is ' + prefix + ' ' + this.name.last + ', and I teach ' + this.subject + '.');
};

var teacher1 = new Teacher('Dave', 'Griffiths', 31, 'male', ['football', 'cookery'], 'mathematics');

teacher1.name.first;
teacher1.interests[0];
teacher1.subject;
teacher1.greeting();