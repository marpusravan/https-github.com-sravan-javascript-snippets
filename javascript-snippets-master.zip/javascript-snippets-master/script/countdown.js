// Recursive countdown

let countdown = (num) => {
	if(num == 0) return num;
	console.log(num);
	var cd = countdown(num-1);
	console.log(cd);
};

countdown(3);