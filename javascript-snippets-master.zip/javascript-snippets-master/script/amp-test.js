"use strict";

setTimeout(function(){
	var app = amplitude.getInstance();
	var sampleJson = {
	      "username" : "john doe"
	};
	var identify = new amplitude.Identify();
	var bukt = null;

	

	// Returns a random integer between min (included) and max (included) Using Math.round() will give you a non-uniform distribution!
	function getRandomBucketValue(min,max){
	    return Math.floor(Math.random() * (max - min + 1)) + min;
	}

	function sendAmplitude(){
	      console.log(app.options["deviceId"]);
	      // app.logEvent('test-event',sampleJson);
	      var rand = null;
	      if(false){
	      	rand = getRandomBucketValue(0,99);
	      	console.log("once_bukt: ",rand);
	      	bukt = identify.setOnce('once_bukt',rand);
	      }else{
	      	rand = getRandomBucketValue(100,199);
	      	console.log("set_bukt: ",rand);
	      	bukt = identify.set('once_bukt',rand);
	      }
		amplitude.identify(bukt);
	      
	}

	sendAmplitude();

},2000);
