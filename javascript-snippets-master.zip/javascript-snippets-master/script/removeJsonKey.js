var exports = module.exports = {};



exports.removeJsonKey =  function(json,key){
	console.log("chk1: ",JSON.stringify(json));
	if(json.hasOwnProperty(key)){
		delete json[key];
	}
	console.log("chk2: ",JSON.stringify(json));
}

var sampleJson = {
	"first_name" : "John",
	"last_name" : "doe",
	"address" : "007 mystery st"
};


function removeJsonKeys(json,keyArr){
	console.log("chk3: ",json);
	for(var i = 0; i < keyArr.length; i++){
		console.log("chk1: ",keyArr[i]);
		delete json[keyArr[i]];
	}
	console.log('chk2: ',json);
}

removeJsonKeys(sampleJson,["first_name","last_name"]);
