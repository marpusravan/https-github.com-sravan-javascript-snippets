function arrayRemoveDuplicates(dupArr){

	var exists = {}, elem, arr = [];

	for(var i=0;i<dupArr.length;i++){
		elem = dupArr[i];
		if(!exists[elem]){
			arr.push(elem);
			exists[elem] = true;
		}
	}
	console.log(arr);
}

var dupArr = [4,5,6,1,5,7,8,1,1,3,4];
arrayRemoveDuplicates(dupArr);