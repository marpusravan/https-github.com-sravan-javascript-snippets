// Find all prime factors of a number

function primeFactors(number){

}

primeFactors(10); //