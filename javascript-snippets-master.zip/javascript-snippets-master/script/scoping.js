const name = "ravi";

function student() {
  // name = "shiva"; // Assignment to constant variable.
  if (true) {
    var age = 10;
    let standard = "first";
    var grade = "some-grade";
  }

  console.log(age); // 10
  console.log(name);
  // console.log(standard); //standard is not defined
  console.log(grade);
}

student();