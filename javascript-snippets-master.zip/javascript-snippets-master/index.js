var rjk = require("./script/removeJsonKey");

var sampleJson = {
	"first_name" : "John",
	"last_name" : "doe",
	"address" : "007 mystery st"
};

rjk.removeJsonKey(sampleJson,"first_name");