# javascript-snippets
code snippets of javascript

##steps to run
npm install

node express-server.js

open browser with specified port number say http://localhost:3000/
